package com.backend.printmedianenterprise.Enum;

public enum UserRole {

	ADMIN,
	USER
}
