package com.backend.printmedianenterprise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrintmedianenterpriseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrintmedianenterpriseApplication.class, args);
	}

}
