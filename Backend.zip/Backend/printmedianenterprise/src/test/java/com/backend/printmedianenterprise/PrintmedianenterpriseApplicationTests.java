package com.backend.printmedianenterprise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrintmedianenterpriseApplicationTests {

	@Test
	void contextLoads() {
	}

}
